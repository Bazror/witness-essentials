import HttpTransport from './http';
import WsTransport from './ws';

export default {
  http: HttpTransport,
  ws: WsTransport,
};
