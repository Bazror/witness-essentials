const makeConfig = require('./webpack/makeConfig');
exports = module.exports = makeConfig();
