# About
Binary serialization and deserialization library

```js
import {} from "serializer"
```

# Configure
Update `./.npmrc` if you need to change something:
```bash
serializer:hex_dump = false

```
